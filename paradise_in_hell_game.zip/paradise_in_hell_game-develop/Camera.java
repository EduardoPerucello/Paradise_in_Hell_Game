package zelda1;

import java.awt.Graphics;

public class Camera {

    public static int x;
    public static int y;
}